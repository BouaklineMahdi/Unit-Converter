// time_converter.h

#ifndef TIME_CONVERTER_H
#define TIME_CONVERTER_H

void timeConverter();

#endif