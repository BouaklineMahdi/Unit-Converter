// temperature_converter.h

#ifndef TEMPERATURE_CONVERTER_H
#define TEMPERATURE_CONVERTER_H

void temperatureConverter();

#endif